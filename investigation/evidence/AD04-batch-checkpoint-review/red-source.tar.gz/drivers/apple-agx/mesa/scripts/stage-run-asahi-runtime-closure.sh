#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 || ! "$1" =~ ^[A-Za-z0-9-]+$ ]]; then
  echo "usage: $0 RUN_ID" >&2
  exit 64
fi
run_id="$1"
repo_root=$(git rev-parse --show-toplevel)
stage_dir=$(mktemp -d /tmp/ad04-runtime-stage.XXXXXX)
archive="$stage_dir/source.tar.gz"
remote_source="C:/Users/pauls/AD04-runtime-src-${run_id}"
remote_archive="C:/Users/pauls/AD04-runtime-${run_id}.tar.gz"
git -C "$repo_root" ls-files -co --exclude-standard drivers/apple-agx | \
  tar -C "$repo_root" -czf "$archive" -T -
sha256=$(shasum -a 256 "$archive" | awk '{print $1}')
scp -i /Users/pavel/.ssh/windows_builder "$archive" "pauls@192.168.1.24:${remote_archive}"
encoded=$(python3 - "$remote_source" "$remote_archive" "$run_id" <<'PY'
import base64, sys
src, archive, run_id = sys.argv[1:]
script = f'''$ErrorActionPreference='Stop'
if(Test-Path '{src}'){{throw 'Fresh source path required'}}
[void](New-Item -ItemType Directory '{src}')
tar -xf '{archive}' -C '{src}'
if($LASTEXITCODE){{exit $LASTEXITCODE}}
& '{src}\\drivers\\apple-agx\\mesa\\scripts\\run-asahi-runtime-closure.ps1' -Project '{src}' -RunId '{run_id}'
exit $LASTEXITCODE'''
print(base64.b64encode(script.encode('utf-16le')).decode())
PY
)
ssh -i /Users/pavel/.ssh/windows_builder pauls@192.168.1.24 \
  powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand "$encoded"
printf '%s\n' "$sha256"
