param(
  [Parameter(Mandatory=$true)][string]$Project,
  [Parameter(Mandatory=$true)][string]$RunId,
  [ValidateSet('x64','arm64')][string]$Architecture='x64'
)
$ErrorActionPreference='Stop'
if($RunId -notmatch '^[A-Za-z0-9-]+$'){ throw 'Invalid RunId' }
$root='C:\Users\pauls\AD04-fullcompiler-001'
$output=Join-Path $root ('asahi-runtime-'+$Architecture+'-'+$RunId)
if(Test-Path $output){ throw 'Fresh RunId required' }
$python=Join-Path $root 'venv\Scripts\python.exe'
& $python "$Project\drivers\apple-agx\mesa\scripts\build-asahi-runtime-closure.py" --project $Project --architecture $Architecture --output $output
$exit=$LASTEXITCODE
$summary=@{project=$Project; run_id=$RunId; architecture=$Architecture; output=$output; exit=$exit}
$summary | ConvertTo-Json | Set-Content (Join-Path $output 'runner-result.json')
$summary | ConvertTo-Json
exit $exit
