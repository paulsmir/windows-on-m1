#include "render_win32_transport.h"

#define ADMISSION_WIN32_NULL ((void *)0)
#define ADMISSION_WIN32_ACCESS_MASK                                          \
  ((APPLE_AGX_U32)AppleAgxWin32AccessRead |                                 \
   (APPLE_AGX_U32)AppleAgxWin32AccessWrite |                                \
   (APPLE_AGX_U32)AppleAgxWin32AccessExecute)
#define ADMISSION_WIN32_BUFFER_ACCESS_MASK                                   \
  ((APPLE_AGX_U32)AppleAgxWin32BufferCpuRead |                              \
   (APPLE_AGX_U32)AppleAgxWin32BufferCpuWrite |                             \
   (APPLE_AGX_U32)AppleAgxWin32BufferGpuRead |                              \
   (APPLE_AGX_U32)AppleAgxWin32BufferGpuWrite)

ADMISSION_WIN32_TRANSPORT_RESULT AdmissionWin32AllocationCreateValidate(
    const void *PrivateData, APPLE_AGX_U32 PrivateDataBytes,
    ADMISSION_ALLOCATION_DESCRIPTION *Description,
    APPLE_AGX_U32 *ClassId, APPLE_AGX_U32 *Flags) {
  const ADMISSION_WIN32_ALLOCATION_CREATE *create =
      (const ADMISSION_WIN32_ALLOCATION_CREATE *)PrivateData;
  const ADMISSION_ALLOCATION_DESCRIPTION *allocation;
  APPLE_AGX_U32 classId = 0u;
  APPLE_AGX_U32 flags = 0u;
  if (PrivateData == ADMISSION_WIN32_NULL || Description == ADMISSION_WIN32_NULL ||
      ClassId == ADMISSION_WIN32_NULL || Flags == ADMISSION_WIN32_NULL)
    return AdmissionWin32TransportArgument;
  if (PrivateDataBytes == sizeof(ADMISSION_ALLOCATION_DESCRIPTION)) {
    allocation = (const ADMISSION_ALLOCATION_DESCRIPTION *)PrivateData;
    if (!AdmissionAllocationDescriptionValid(allocation))
      return AdmissionWin32TransportClass;
  } else {
    if (PrivateDataBytes != sizeof(*create) ||
        create->Magic != ADMISSION_WIN32_ALLOCATION_MAGIC ||
        create->Version != ADMISSION_WIN32_ALLOCATION_VERSION ||
        create->Bytes != sizeof(*create) || create->Reserved[0] != 0u ||
        create->Reserved[1] != 0u ||
        create->ClassId < AgxWin32BufferClassGeneral ||
        create->ClassId > AgxWin32BufferClassEncoder ||
        create->Flags == 0u ||
        (create->Flags & ~ADMISSION_WIN32_BUFFER_ACCESS_MASK) != 0u)
      return AdmissionWin32TransportClass;
    if (create->ClassId == AgxWin32BufferClassGeneral) {
      if ((create->Flags & (AppleAgxWin32BufferCpuRead |
                            AppleAgxWin32BufferCpuWrite)) == 0u ||
          (create->Flags & (AppleAgxWin32BufferGpuRead |
                            AppleAgxWin32BufferGpuWrite)) == 0u)
        return AdmissionWin32TransportAccess;
    } else if (create->Flags !=
               (AppleAgxWin32BufferCpuWrite | AppleAgxWin32BufferGpuRead)) {
      return AdmissionWin32TransportAccess;
    }
    allocation = &create->Allocation;
    classId = create->ClassId;
    flags = create->Flags;
    if (!AdmissionAllocationDescriptionValid(allocation) ||
        allocation->Type != ADMISSION_WIN32_ALLOCATION_STAGING_CPUVISIBLE ||
        allocation->Format != ADMISSION_WIN32_ALLOCATION_FORMAT_A8 ||
        allocation->CpuVisible != 1u || allocation->Height != 1u ||
        allocation->Width != allocation->Pitch ||
        allocation->Size != allocation->Width ||
        allocation->Size > 0x01000000ULL ||
        (allocation->Size & 0x3fffULL) != 0ULL)
      return AdmissionWin32TransportClass;
  }
  *Description = *allocation;
  *ClassId = classId;
  *Flags = flags;
  return AdmissionWin32TransportSuccess;
}

static int AdmissionWin32RangesOverlap(
    const APPLE_AGX_WIN32_ALLOCATION_REFERENCE *Left,
    const APPLE_AGX_WIN32_ALLOCATION_REFERENCE *Right) {
  APPLE_AGX_U64 leftEnd = Left->Offset + Left->Bytes;
  APPLE_AGX_U64 rightEnd = Right->Offset + Right->Bytes;
  return Left->Offset < rightEnd && Right->Offset < leftEnd;
}

/* Version 3 captures Mesa native source streams byte-exactly. Offsets remain
 * word aligned: only the final span may end mid-word. This is source-copy
 * metadata, not a widened register, pointer or destination alignment rule. */
static int AdmissionWin32ExactNativeSpan(
    const APPLE_AGX_WIN32_COMMAND_VIEW *View,
    const APPLE_AGX_WIN32_ALLOCATION_REFERENCE *Reference) {
  if (View == ADMISSION_WIN32_NULL || View->Header == ADMISSION_WIN32_NULL ||
      Reference == ADMISSION_WIN32_NULL ||
      View->Header->Opcode != AppleAgxWin32OpcodeDraw ||
      View->Header->Version != APPLE_AGX_WIN32_COMMAND_VERSION_NATIVE_USC ||
      Reference->Access != AppleAgxWin32AccessRead)
    return 0;
  return Reference->Role == AppleAgxWin32RoleConstant ||
         Reference->Role == AppleAgxWin32RoleShaderRodata ||
         Reference->Role == AppleAgxWin32RoleUscPipeline;
}

static ADMISSION_WIN32_TRANSPORT_RESULT AdmissionWin32ReferenceClass(
    const APPLE_AGX_WIN32_ALLOCATION_REFERENCE *Reference,
    const ADMISSION_WIN32_ALLOCATION_FACT *Fact, APPLE_AGX_U16 CommandVersion) {
  APPLE_AGX_U32 requiredClass;
  if (Reference == ADMISSION_WIN32_NULL || Fact == ADMISSION_WIN32_NULL)
    return AdmissionWin32TransportArgument;
  switch (Reference->Role) {
  case AppleAgxWin32RoleRenderTarget:
    if (Fact->ClassId == 0u)
      return AdmissionWin32TransportSuccess;
    requiredClass = AgxWin32BufferClassGeneral;
    break;
  case AppleAgxWin32RoleVertex:
  case AppleAgxWin32RoleIndex:
  case AppleAgxWin32RoleConstant:
  case AppleAgxWin32RoleTexture:
    requiredClass = AgxWin32BufferClassGeneral;
    break;
  case AppleAgxWin32RoleShader:
  case AppleAgxWin32RoleShaderRodata:
    requiredClass = AgxWin32BufferClassShader;
    break;
  case AppleAgxWin32RoleDescriptor:
  case AppleAgxWin32RoleScissor:
  case AppleAgxWin32RoleDepthBias:
    if (Fact->ClassId == AgxWin32BufferClassGeneral &&
        CommandVersion == APPLE_AGX_WIN32_COMMAND_VERSION_NATIVE_USC &&
        Reference->Access == AppleAgxWin32AccessRead)
      requiredClass = AgxWin32BufferClassGeneral;
    else
      requiredClass = AgxWin32BufferClassEncoder;
    break;
  case AppleAgxWin32RoleUscPipeline:
  case AppleAgxWin32RoleEncoder:
    requiredClass = AgxWin32BufferClassEncoder;
    break;
  default:
    return AdmissionWin32TransportClass;
  }
  if (Fact->ClassId != requiredClass)
    return AdmissionWin32TransportClass;
  if (((Reference->Access & (AppleAgxWin32AccessRead |
                             AppleAgxWin32AccessExecute)) != 0u &&
       (Fact->Flags & AppleAgxWin32BufferGpuRead) == 0u) ||
      ((Reference->Access & AppleAgxWin32AccessWrite) != 0u &&
       (Fact->Flags & AppleAgxWin32BufferGpuWrite) == 0u))
    return AdmissionWin32TransportAccess;
  return AdmissionWin32TransportSuccess;
}

ADMISSION_WIN32_TRANSPORT_RESULT AdmissionWin32ContextCreateValidate(
    const void *PrivateData, APPLE_AGX_U32 PrivateDataBytes,
    APPLE_AGX_BOOL SystemOrGdi, APPLE_AGX_BOOL LegacyQualificationAllowed,
    APPLE_AGX_U32 *Generation, APPLE_AGX_BOOL *Win32Transport) {
  const ADMISSION_WIN32_CONTEXT_CREATE *create =
      (const ADMISSION_WIN32_CONTEXT_CREATE *)PrivateData;
  APPLE_AGX_U32 generation;
  APPLE_AGX_BOOL win32;
  if (Generation == ADMISSION_WIN32_NULL ||
      Win32Transport == ADMISSION_WIN32_NULL)
    return AdmissionWin32TransportArgument;
  if (SystemOrGdi) {
    if (PrivateData != ADMISSION_WIN32_NULL || PrivateDataBytes != 0u)
      return AdmissionWin32TransportContext;
    generation = 0u;
    win32 = APPLE_AGX_FALSE;
  } else if (PrivateData == ADMISSION_WIN32_NULL && PrivateDataBytes == 0u &&
             LegacyQualificationAllowed) {
    generation = 0u;
    win32 = APPLE_AGX_FALSE;
  } else {
    if (create == ADMISSION_WIN32_NULL ||
        PrivateDataBytes != sizeof(*create) ||
        create->Magic != ADMISSION_WIN32_CONTEXT_MAGIC ||
        create->Version != ADMISSION_WIN32_CONTEXT_VERSION ||
        create->Bytes != sizeof(*create) || create->Generation == 0u ||
        create->Reserved != 0u)
      return AdmissionWin32TransportContext;
    generation = create->Generation;
    win32 = APPLE_AGX_TRUE;
  }
  *Generation = generation;
  *Win32Transport = win32;
  return AdmissionWin32TransportSuccess;
}

ADMISSION_WIN32_TRANSPORT_RESULT AdmissionWin32ValidateReferences(
    const APPLE_AGX_WIN32_COMMAND_VIEW *View,
    APPLE_AGX_U32 ExpectedGeneration,
    ADMISSION_WIN32_LOOKUP_ALLOCATION Lookup, void *LookupContext,
    ADMISSION_WIN32_ALLOCATION_FACT *Facts,
    APPLE_AGX_U32 FactCapacity) {
  ADMISSION_WIN32_ALLOCATION_FACT local[
      APPLE_AGX_WIN32_COMMAND_MAX_REFERENCES];
  APPLE_AGX_U32 index;
  APPLE_AGX_U32 other;

  if (View == ADMISSION_WIN32_NULL || View->Header == ADMISSION_WIN32_NULL ||
      View->References == ADMISSION_WIN32_NULL ||
      ExpectedGeneration == 0u || Lookup == ADMISSION_WIN32_NULL ||
      Facts == ADMISSION_WIN32_NULL || View->Header->ReferenceCount == 0u ||
      View->Header->ReferenceCount > APPLE_AGX_WIN32_COMMAND_MAX_REFERENCES ||
      FactCapacity < View->Header->ReferenceCount)
    return AdmissionWin32TransportArgument;
  if (View->Header->Generation != ExpectedGeneration)
    return AdmissionWin32TransportStaleGeneration;

  for (index = 0u; index < View->Header->ReferenceCount; ++index) {
    const APPLE_AGX_WIN32_ALLOCATION_REFERENCE *reference =
        &View->References[index];
    APPLE_AGX_U64 requiredBytes = 0ULL;
    if (!Lookup(LookupContext, reference->AllocationIndex, &local[index]) ||
        local[index].AllocationToken == 0ULL || local[index].Bytes == 0ULL)
      return AdmissionWin32TransportLookup;
    if (local[index].Generation != ExpectedGeneration)
      return AdmissionWin32TransportStaleGeneration;
    if ((reference->Offset & 3ULL) != 0ULL ||
        ((reference->Bytes & 3ULL) != 0ULL &&
         !AdmissionWin32ExactNativeSpan(View, reference)))
      return AdmissionWin32TransportAlignment;
    if (reference->Bytes == 0ULL || reference->Offset > local[index].Bytes ||
        reference->Bytes > local[index].Bytes - reference->Offset)
      return AdmissionWin32TransportRange;
    if (reference->Access == 0u ||
        (reference->Access & ~ADMISSION_WIN32_ACCESS_MASK) != 0u ||
        ((reference->Access & (APPLE_AGX_U32)AppleAgxWin32AccessWrite) != 0u &&
         !local[index].Writable))
      return AdmissionWin32TransportAccess;
    if ((reference->Access & (APPLE_AGX_U32)AppleAgxWin32AccessWrite) != 0u &&
        local[index].ActiveForDisplay)
      return AdmissionWin32TransportActiveDisplay;
    if (View->Header->Opcode == AppleAgxWin32OpcodeDraw) {
      ADMISSION_WIN32_TRANSPORT_RESULT classResult =
          AdmissionWin32ReferenceClass(reference, &local[index],
                                       View->Header->Version);
      if (classResult != AdmissionWin32TransportSuccess)
        return classResult;
    }
    if (View->Clear != ADMISSION_WIN32_NULL &&
        View->Clear->DestinationReference == index) {
      requiredBytes = (APPLE_AGX_U64)View->Clear->SurfacePitch *
                      (APPLE_AGX_U64)View->Clear->SurfaceHeight;
      if (reference->Bytes < requiredBytes)
        return AdmissionWin32TransportRange;
    }
    if (View->Draw != ADMISSION_WIN32_NULL &&
        View->Draw->DestinationReference == index) {
      requiredBytes = (APPLE_AGX_U64)View->Draw->SurfacePitch *
                      (APPLE_AGX_U64)View->Draw->SurfaceHeight;
      if (reference->Bytes < requiredBytes)
        return AdmissionWin32TransportRange;
    }
  }

  if (View->Header->Opcode == AppleAgxWin32OpcodeDraw) {
    if (View->Draw == ADMISSION_WIN32_NULL ||
        View->Relocations == ADMISSION_WIN32_NULL)
      return AdmissionWin32TransportArgument;
    for (index = 0u; index < View->Draw->RelocationCount; ++index) {
      const APPLE_AGX_WIN32_RELOCATION *left = &View->Relocations[index];
      APPLE_AGX_U32 relocationOther;
      APPLE_AGX_U32 leftReference = left->DestinationReference;
      APPLE_AGX_U64 leftOffset =
          View->References[leftReference].Offset + left->DestinationOffset;
      for (relocationOther = index + 1u;
           relocationOther < View->Draw->RelocationCount;
           ++relocationOther) {
        const APPLE_AGX_WIN32_RELOCATION *right =
            &View->Relocations[relocationOther];
        APPLE_AGX_U32 rightReference = right->DestinationReference;
        APPLE_AGX_U64 rightOffset =
            View->References[rightReference].Offset +
            right->DestinationOffset;
        if (local[leftReference].AllocationToken ==
                local[rightReference].AllocationToken &&
            leftOffset < rightOffset + left->WidthBytes &&
            rightOffset < leftOffset + right->WidthBytes)
          return AdmissionWin32TransportOverlap;
      }
    }
  }

  for (index = 0u; index < View->Header->ReferenceCount; ++index) {
    for (other = index + 1u; other < View->Header->ReferenceCount; ++other) {
      if (local[index].AllocationToken == local[other].AllocationToken &&
          ((View->References[index].Access |
            View->References[other].Access) &
           (APPLE_AGX_U32)AppleAgxWin32AccessWrite) != 0u &&
          AdmissionWin32RangesOverlap(&View->References[index],
                                      &View->References[other]))
        return AdmissionWin32TransportOverlap;
    }
  }

  for (index = 0u; index < View->Header->ReferenceCount; ++index)
    Facts[index] = local[index];
  return AdmissionWin32TransportSuccess;
}
